const challenges = [
  { image: "images/vagrant.webp", answers: ["vagrant", "Vagrant"] },
  { image: "images/Boreal_outrider_knight.webp", answers: ["boreal valley knight", "outrider"] },
  { image: "images/Darkstalker.jpg", answers: ["darkstalker"] },
  { image: "images/assasin.jpg", answers: ["manikins"] },
  { image: "images/mastodon.webp", answers: ["mastodon"] },
  { image: "images/alonne_knight.webp", answers: ["alonne knight"] },
  { image: "images/misbegotten.webp", answers: ["misbegotten"] },
  { image: "images/Darkstalker.jpg", answers: ["darkstalker"] },
];

let current = 0;
let lives = 5;

function checkAnswer() {
  const input = document.getElementById("userAnswer").value.trim().toLowerCase();
  const feedback = document.getElementById("feedback");
  const livesDisplay = document.getElementById("lives");

  // Get array of acceptable answers for the current challenge
  const correctAnswers = challenges[current].answers.map(ans => ans.toLowerCase());

  if (correctAnswers.includes(input)) {
    feedback.textContent = "✅ Correct!";
    current++;

    if (current < challenges.length) {
      showNextChallenge();
    } else {
      feedback.textContent = "🎉 You completed all challenges!";
      document.getElementById("gameImage").style.display = "none";
    }

  } else {
    lives--;
    livesDisplay.textContent = lives;

    if (lives > 0) {
      feedback.textContent = "❌ Wrong! Try again.";
    } else {
      feedback.textContent = "💀 Game Over!";
      document.querySelector("button").disabled = true;
    }
  }

  document.getElementById("userAnswer").value = "";
}

function showNextChallenge() {
  document.getElementById("gameImage").src = challenges[current].image;
  document.getElementById("userAnswer").value = "";
  document.getElementById("feedback").textContent = "";
}

// Load the first image when the page loads
window.onload = showNextChallenge;
